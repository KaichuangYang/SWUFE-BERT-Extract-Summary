"""Top-level package for extract_summary_finetune."""

__author__ = """Yu Zheng"""
__email__ = 'yu.zheng@inboc.net'
__version__ = '0.1.0'
