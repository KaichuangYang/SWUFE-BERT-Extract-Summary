import sys
from extract_summary_finetune.cli.commands import main_cli


def run_tool():
    sys.exit(main_cli())
