"""Unit test package for mnist."""
