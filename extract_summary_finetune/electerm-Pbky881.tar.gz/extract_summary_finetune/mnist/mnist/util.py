import torch
import numpy as np
from mnist.device import move_to_device
from mnist.log import BatchLog

import pendulum




def set_seed(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)


def rescale_image(img, mean_gray, stddev_gray):
    normal_image = img.numpy() * stddev_gray + mean_gray
    return normal_image

def process_epoch(
        model,
        loss_func,
        optimizer,
        dataloader,
        epoch,
        device,
        timezone='Asia/Shanghai'
):

    mode = 'train' if model.training else 'test'
    batch_log=BatchLog(mode)
    for i, (data, label) in enumerate(dataloader):
        batch_start_time=pendulum.now(timezone)
        data = data.to(device)
        label = label.to(device)
        pred = model(data)
        loss = loss_func(pred, label)
        if model.training:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        batch_log.add_log(epoch, loss, pred, label)
        batch_end_time=pendulum.now(timezone)
        batch_log.add_execution_time(batch_start_time, batch_end_time)
    return batch_log