from torchvision import transforms
from torch.utils.data import Dataset
from PIL import Image

class MnistDataset(Dataset):
    def __init__(self, data, targets, is_normalize=False):
        self.data=data
        self.targets=targets
        if is_normalize:
            mean_gray, stddev_gray = 0.1307, 0.3081
            self.transforms = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((mean_gray,), (stddev_gray,))])
        else:
            self.transforms = transforms.Compose([
                transforms.ToTensor()])

    def __getitem__(self,index):
        img, target = self.data[index], int(self.targets[index])
        img = Image.fromarray(img.numpy(), mode="L")
        img = self.transforms(img)
        return img, target

    def __len__(self):
        return self.data.shape[0]
