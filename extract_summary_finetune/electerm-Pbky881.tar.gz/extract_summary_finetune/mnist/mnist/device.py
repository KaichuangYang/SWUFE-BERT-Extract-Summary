import torch

def get_device():
    if torch.cuda.is_available():
        device = 'cuda'
    elif torch.backends.mps.is_available():
        device = 'mps'
    else:
        device= 'cpu'
    return device

def get_cuda_info():
    if torch.cuda.is_available():
        device_count=torch.cuda.device_count()
        current_device=torch.cuda.current_device()
        cuda_info={'device':'gpu',
                   'device_count':device_count,
                   'current_device_address': torch.cuda.device(current_device),
                   'current_device_name':torch.cuda.get_device_name(current_device)}
        for i in range(device_count):
            cuda_info.update({f'device_{i}_address':torch.cuda.device(i),
                              f'device_{i}_name':torch.cuda.get_device_name(i)
                              })
        return cuda_info
    return None

def move_to_device(obj, device):
    """
    obj: the python object to move to a device, or to move its contents to a device
    device: the compute device to move objects to
    """
    if isinstance(obj, list):
        return [move_to_device(x, device) for x in obj]
    elif isinstance(obj, tuple):
        return tuple(move_to_device(list(obj), device))
    elif isinstance(obj, set):
        return set(move_to_device(list(obj), device))
    elif isinstance(obj, dict):
        new_dict = dict()
        for key, value in obj.items():
            new_dict[move_to_device(key, device)] = move_to_device(value, device)
        return new_dict
    elif hasattr(obj, "to"):
        return obj.to(device)
    else:
        return obj