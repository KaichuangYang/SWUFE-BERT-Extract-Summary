import sys
from mnist.cli.commands import main_cli


def run_tool():
    sys.exit(main_cli())
