import click

from torchvision import datasets

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from mnist.data import MnistDataset
from mnist.model import MnistCNNBN, MnistCNN, MnistFeedForward, MnistSimpleCNN
from mnist.util import set_seed
from mnist.mnist import train_mnist
from sklearn.metrics import accuracy_score
import dill

model_dict={
    'mnist_cnn':MnistCNN,
    'mnist_cnn_bn':MnistCNNBN,
    'mnist_feed_forward':MnistFeedForward,
    'mnist_simple_cnn':MnistSimpleCNN
}

@click.group(name='mnist')
def cli():
    """ Run Mnist Experiment """
    pass


@cli.command()
@click.option('-p', '--data_path', required=True, type=click.Path(resolve_path=True))
@click.option('-n', '--network', required=True, type=str)
@click.option('-s', '--batch_size', required=True, type=int)
@click.option('-d', '--device', required=True, type=str)
@click.option('-e', '--epochs', required=True, type=int)
@click.option('-t', '--timezone', required=True, default='Asia/Shanghai')
@click.option('-o', '--output_path', required=True, type=click.Path(resolve_path=True))
def x01_run_mnist_training(data_path, network, batch_size, device, epochs, timezone, output_path):
    set_seed(1)
    train_data = datasets.MNIST(root=data_path, train=True, download=False)
    test_data = datasets.MNIST(root=data_path, train=False)
    train_dataset = MnistDataset(train_data.data, train_data.targets)
    test_dataset = MnistDataset(test_data.data, test_data.targets)
    train_dataloader = DataLoader(dataset=train_dataset,
                                  batch_size=batch_size,
                                  shuffle=True)

    test_dataloader = DataLoader(dataset=test_dataset,
                                 batch_size=batch_size,
                                 shuffle=False)
    model = model_dict[network]()
    model = model.to(device)
    loss_func = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    extra_metric = {'accuracy': accuracy_score}
    is_classification = True
    result = train_mnist(
        model,
        loss_func,
        optimizer,
        train_dataloader,
        test_dataloader,
        epochs,
        is_classification,
        extra_metric,
        device,
        timezone
    )
    with open(output_path, "wb") as f:
        dill.dump(result, f)
    del model
    torch.cuda.empty_cache()
