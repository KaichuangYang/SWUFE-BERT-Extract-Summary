import click

@click.group()
def main_cli():
    """ mnist """
    pass

from .cmd_run import cli as mnist
main_cli.add_command(mnist())
