import torch.nn as nn

class MnistFeedForward(nn.Module):
    def __init__(self):
        super(MnistFeedForward, self).__init__()
        self.fc1=nn.Linear(in_features=28*28, out_features=256)
        self.fc2=nn.Linear(in_features=256,out_features=10)
        self.tanh=nn.Tanh()
        self.flatten=nn.Flatten()
    def forward(self, x):
        out = self.flatten(x)
        out = self.fc1(out)
        out = self.tanh(out)
        out = self.fc2(out)
        return out

class MnistSimpleCNN(nn.Module):
    def __init__(self):
        super(MnistSimpleCNN, self).__init__()
        self.conv1=nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, padding=1, stride=1)
        self.fc1=nn.Linear(in_features=16*28*28, out_features=10)
        self.tanh=nn.Tanh()
        self.flatten=nn.Flatten()

    def forward(self, x):
        out = self.conv1(x)
        out = self.tanh(out)
        out = self.flatten(out)
        out = self.fc1(out)
        return out

class MnistCNN(nn.Module):
    def __init__(self):
        super(MnistCNN, self).__init__()
        self.conv1=nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, padding=1, stride=1)
        self.conv2=nn.Conv2d(in_channels=16, out_channels=16, kernel_size=3, padding=1, stride=1)
        self.conv3=nn.Conv2d(in_channels=16, out_channels=16, kernel_size=3, padding=1, stride=1)
        self.maxpool=nn.MaxPool2d(2)
        self.conv4=nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=1, stride=1)
        self.conv5=nn.Conv2d(in_channels=32, out_channels=32, kernel_size=3, padding=1, stride=1)
        self.conv6=nn.Conv2d(in_channels=32, out_channels=32, kernel_size=3, padding=1, stride=1)
        self.tanh = nn.Tanh()
        self.flatten = nn.Flatten()
        self.fc1=nn.Linear(in_features=32*7*7, out_features=10)
    def forward(self,x):
        out = self.conv1(x)
        out = self.tanh(out)
        out = self.conv2(out)
        out = self.tanh(out)
        out = self.conv3(out)
        out = self.tanh(out)
        out = self.maxpool(out)
        out = self.conv4(out)
        out = self.tanh(out)
        out = self.conv5(out)
        out = self.tanh(out)
        out = self.conv6(out)
        out = self.tanh(out)
        out = self.maxpool(out)
        out = self.flatten(out)
        out = self.fc1(out)
        return out


class MnistCNNBN(nn.Module):
    def __init__(self):
        super(MnistCNNBN, self).__init__()
        self.conv1=nn.Conv2d(in_channels=1, out_channels=8, kernel_size=3, padding=1, stride=1)
        self.batchnorm1=nn.BatchNorm2d(8)
        self.relu=nn.ReLU()
        self.maxpool=nn.MaxPool2d(kernel_size=2)
        self.conv2=nn.Conv2d(in_channels=8, out_channels=32,kernel_size=5, padding=2, stride=1)
        self.batchnorm2=nn.BatchNorm2d(32)
        self.fc1=nn.Linear(in_features=32*7*7, out_features=600)
        self.dropout = nn.Dropout(p=0.5)
        self.fc2=nn.Linear(in_features=600, out_features=10)
        self.flatten=nn.Flatten()
    def forward(self, x):
        out = self.conv1(x)
        out = self.batchnorm1(out)
        out = self.relu(out)
        out = self.maxpool(out)
        out = self.conv2(out)
        out = self.batchnorm2(out)
        out = self.relu(out)
        out = self.maxpool(out)
        out = self.flatten(out)
        out = self.fc1(out)
        out = self.relu(out)
        out = self.dropout(out)
        out =self.fc2(out)
        return out