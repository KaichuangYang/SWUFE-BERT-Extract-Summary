=======
History
=======

0.1.0 (2022-07-15)
------------------

* First release on PyPI.
