import torch
import torch.nn as nn
import math
import numpy as np

def loss_weighted(pred,label):
    if (pred.ndim == 3)+(label.ndim == 3)==2:
        weight = []
        for i in range(label.shape[0]):
            sumamary_sign_postion  = -1
            distance_score = [0 for i in range(label.shape[1])]
            for j in range (label.shape[1]):
                distance_score[j] = math.log((j-sumamary_sign_postion)+1)
                if (j>0) & (label[i][j-1][0].item()==1) :
                    distance_score[j] = distance_score[j-1]
                if label[i][j][0].item()==1:
                    sumamary_sign_postion = j
            row_weight = [[label.shape[1]*item/sum(distance_score)] for item in distance_score]
            weight.append(row_weight)
        return torch.tensor(weight,dtype=float)
    else:
        return "InputError: true_label and pred_label must be .ndim=3 "