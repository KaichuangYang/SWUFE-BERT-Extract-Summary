
import torch.nn as nn
from transformer_model.transformer_encoder import Encoder
class TransformerEncoder(nn.Module):
    ''' A sequence to sequence model with attention mechanism. '''

    def __init__(
            self, d_word_vec, d_model, n_position, d_inner=512,
            n_layers=2, n_head=4, d_k=32, d_v=32, dropout=0.1,
            trg_emb_prj_weight_sharing=True, scale_emb_or_prj='prj'):

        super().__init__()

        assert scale_emb_or_prj in ['emb', 'prj', 'none']
        scale_emb = (scale_emb_or_prj == 'emb') if trg_emb_prj_weight_sharing else False
        self.scale_prj = (scale_emb_or_prj == 'prj') if trg_emb_prj_weight_sharing else False
        self.d_model = d_model

        self.encoder = Encoder(
            n_position=n_position,
            d_word_vec=d_word_vec, d_model=d_model, d_inner=d_inner,
            n_layers=n_layers, n_head=n_head, d_k=d_k, d_v=d_v, dropout=dropout, scale_emb=scale_emb)

        self.liner1 = nn.Linear(d_model, 256, bias=False)
        self.liner2 = nn.Linear(256, 64, bias=False)
        self.liner3 = nn.Linear(64, 1, bias=False)

        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

        assert d_model == d_word_vec

    def forward(self, x):
        enc_output, *_ = self.encoder(x)
        output = self.liner1(enc_output)
        output = nn.Tanh()(output)
        output = self.liner2(output)
        output = nn.Tanh()(output)
        output = self.liner3(output)
        output = nn.Sigmoid()(output)
        return output