=======
History
=======

0.1.0 (2022-07-13)
------------------

* First release on PyPI.
